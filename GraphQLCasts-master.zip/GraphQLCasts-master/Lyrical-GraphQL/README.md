# Lyrical-GraphQL
Starter project from a GraphQL course on Udemy.com
