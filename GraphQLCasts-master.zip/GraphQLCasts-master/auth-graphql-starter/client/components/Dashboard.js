import React from 'react';

export default () => {
  return <div>You are logged in.</div>
};
